export const Config={

    API_BASE_URL : "https://localhost:44320/api/"
}