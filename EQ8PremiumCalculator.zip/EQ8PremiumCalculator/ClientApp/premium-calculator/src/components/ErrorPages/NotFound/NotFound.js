import React from "react";
import "./NotFound.css";
const notFound = () => {
  return <p className={"notFound"}>"404 PAGE NOT FOUND!"</p>;
};

export default notFound;
